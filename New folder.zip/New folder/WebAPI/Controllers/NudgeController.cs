﻿using System.Net.Http;
using System.Web.Http;
using Domain.Repositories;
using log4net;

namespace WebAPI.Controllers
{
    [RoutePrefix("api/v1.0/nudge")]
    public class NudgeController : ApiController
    {
        private readonly ILog _logger;
        private readonly IDataClient _dataClient;
        public NudgeController(ILog logger,IDataClient dataClient)
        {
            _dataClient = dataClient;
            _logger = logger;
        }

        [HttpGet]
        public bool Get()
        {
            bool result = false;
            if (_dataClient.Nudge())
            {
                result = true;
            }
            else
            {
                result = false;
            }
            return result;
        }
    }
}

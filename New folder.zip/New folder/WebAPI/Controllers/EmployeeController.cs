﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Domain.Repositories;
using log4net;
using Newtonsoft.Json;

namespace WebAPI.Controllers
{
    [RoutePrefix("api/v1.0/employee")]
    public class EmployeeController : ApiController
    {
        private readonly ILog _logger;
        private readonly IEmployeeRepository _employeeRepository;
        public EmployeeController(ILog logger, IEmployeeRepository employeeRepository)
        {
            _logger = logger;
            _employeeRepository = employeeRepository;
        }

        [HttpGet]
        public HttpResponseMessage GetAllEmployees()
        {
            var result = _employeeRepository.GetAllEmployees();
            if (result != null)
            {
                _logger.Info(JsonConvert.SerializeObject(result));
               return Request.CreateResponse(HttpStatusCode.OK, result);
            }
            return Request.CreateResponse(HttpStatusCode.InternalServerError, "Something went wrong");
        }

        [HttpGet]
        public HttpResponseMessage GetEmployee(int id)
        {
            var result = _employeeRepository.GetEmployeeById(id);
            if (result != null)
            {
                _logger.Info(JsonConvert.SerializeObject(result));
                return Request.CreateResponse(HttpStatusCode.OK, result);
            }
            return Request.CreateResponse(HttpStatusCode.InternalServerError, "Something went wrong");
        }
    }
}

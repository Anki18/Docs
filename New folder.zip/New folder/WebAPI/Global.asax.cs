﻿using System.Reflection;
using System.Web.Http;
using Autofac;
using Autofac.Integration.WebApi;
using log4net;
using log4net.Config;

namespace WebAPI
{
    public class WebApiApplication : System.Web.HttpApplication
    {
        protected void Application_Start()
        {
            GlobalConfiguration.Configure(WebApiConfig.Register);
            //configure logger
            XmlConfigurator.Configure();

            var builder = new ContainerBuilder();
            builder.RegisterApiControllers(Assembly.GetExecutingAssembly()).InstancePerRequest();
            builder.RegisterInstance<ILog>(LogManager.GetLogger(typeof(System.Object)));
            builder.RegisterAssemblyTypes(new Assembly[]
            {
                Assembly.Load("Domain"),
                Assembly.Load("Storage"),
            }).Where(t => !string.IsNullOrWhiteSpace(t.Namespace) && (t.Namespace.Contains("Repositories")))
            .AsImplementedInterfaces().SingleInstance();

            ILifetimeScope container = builder.Build();

            var resolver = new AutofacWebApiDependencyResolver(container);

            GlobalConfiguration.Configuration.DependencyResolver = resolver;
        }
    }
}

﻿using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Hosting;

namespace Tests
{
    public class TestBase
    {
        protected static void PrepareController(ApiController controller)
        {
            controller.Request = new HttpRequestMessage();
            controller.Request.Properties.Add(HttpPropertyKeys.HttpConfigurationKey, new HttpConfiguration());
        }
    }
}

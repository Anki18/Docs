﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using Domain.Repositories;
using log4net;
using WebAPI.Controllers;
using System.Net.Http;
using System.Threading.Tasks;
using System.Net;
using Newtonsoft.Json;
using System.Collections.Generic;
using Domain;

namespace Tests
{
    [TestClass]
    public class EmployeeTests: TestBase
    {
        private Mock<IEmployeeRepository> _employeeRepositoryMock;
        private Mock<ILog> _mockLog;

        public EmployeeTests()
        {
            _employeeRepositoryMock = new Mock<IEmployeeRepository>();
            _mockLog = new Mock<ILog>(); 
        }
        [TestMethod]
        public void EmployeeController_ReturnSuccessAsync()
        {
            Employee emp = new Employee()
            {
                Id = 1,
                Name = "test",
                Salary = 45000,
                DeptId = 1
            };
            List<Employee> empList = new List<Employee>();
            empList.Add(emp);
            using (var controller = new EmployeeController(_mockLog.Object, _employeeRepositoryMock.Object))
            {
                PrepareController(controller);
                _employeeRepositoryMock.Setup(s => s.GetAllEmployees()).Returns(empList);//(Task.FromResult(empList))
                HttpResponseMessage response =  controller.GetAllEmployees();
                Assert.IsNotNull(response, "Response Should not be null");
                Assert.IsTrue(response.IsSuccessStatusCode, "Success status code should not be false");
                Assert.AreEqual(HttpStatusCode.OK, response.StatusCode, "Unexpected result");
                var resultBody = response.Content.ReadAsStringAsync().Result;
                List<Employee> result = JsonConvert.DeserializeObject<List<Employee>>(resultBody);
            }
        }
    }
}

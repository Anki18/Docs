﻿using Domain.Repositories;

namespace Storage.Repositories
{
    public class DataClient : IDataClient
    {
        public bool Nudge()
        {
            using (var dbContext = new DatabaseContext())
            {
                if (dbContext.Database.Exists())
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }
    }
}

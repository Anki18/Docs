﻿using System.Collections.Generic;
using System.Linq;
using Domain;
using Domain.Repositories;

namespace Storage.Repositories
{
    public class EmployeeRepository : IEmployeeRepository
    {
        public EmployeeRepository()
        {

        }
        public List<Employee> GetAllEmployees()
        {
            List<Employee> employees = null;
            using (var dbContext = new DatabaseContext())
            {
               employees = dbContext.Employee.ToList();
            }
            return employees;
        }

        public Employee GetEmployeeById(int id)
        {
            Employee employee = null;
            using (var dbContext = new DatabaseContext())
            {
                employee = dbContext.Employee.Where(x=>x.Id == id).ToList().FirstOrDefault();
            }
            return employee;
        }
    }
}
